// Initialize variables
var uptimeHost = 'uptime-demo';
var debugMode = true;
var interval = null;
var requestString = null;
var myChart = null;
var myChartDimensions = null;
var renderSuccessful = null;  //Add this later
var divsToDim = ['#widgetChart', '#widgetSettings'];
var settings = {deviceId: null, portId: null, metricId: null, refreshInterval: null,
                chartTitle: null, seriesTitle: null, thresholdValues: []};
var refreshIntervalOptions = {"10000" : "10 seconds", "30000" : "30 seconds",
    "60000" : "minute", "300000" : "5 minutes",
    "600000" : "10 minutes"}
var refreshIntervalSliderOptions = {"1" : "10000", "2" : "30000", "3" : "60000",
    "4" : "300000", "5" : "600000" }
var gadgetInstanceId = uptimeGadget.getInstanceId();
var gadgetGetMetricsPath = '/gadgets/instances/' + gadgetInstanceId + '/getNetworkDeviceMetrics.php';
var normalGetMetricsPath = 'getNetworkDeviceMetrics.php';
var relativeGetMetricsPath = '/gadgets/networkgauge/getNetworkDeviceMetrics.php';
var getMetricsPath = relativeGetMetricsPath;

if (debugMode) {
    console.log('Metric Chart: Debug logging enabled');
}

if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Current path to getNetworkDeviceMetrics.php: '
    + getMetricsPath)};

// Initialize handlers
uptimeGadget.registerOnEditHandler(showEditPanel);
uptimeGadget.registerOnLoadHandler(function(onLoadData) {
    if (onLoadData.hasPreloadedSettings()) {
        goodLoad(onLoadData.settings);
    } else {
        uptimeGadget.loadSettings().then(goodLoad, onBadAjax);
    }
});
uptimeGadget.registerOnResizeHandler(resizeGadget);

// Populate configuration options
populateOptions();

// Unleash the popovers!
var popOptions = { delay: {show: 1000}}
var popTargets = [  $("#devices"), $("#ports"), $("#metrics"), $("#performance-metrics-div"),
                    $("#refreshIntervalSliderAndLabel"), $("#thresholds-div"), $("#title")]
$.each (popTargets, function(index, target) {
    target.popover(popOptions)
});

///////////////////////////////////////
var topChartOptions = {
    chart: {
        renderTo: 'topChart',
        type: 'gauge',
        plotBackgroundColor: null,
        plotBackgroundImage: null,
        plotBorderWidth: 0,
        plotShadow: false,
        marginTop: -150,
        marginBottom: -350
    },
    credits: {enabled: false},
    title: {
        text: ''
    },
    plotOptions: {
        gauge: {
            dial: {
                radius: '75%',
                baseWidth: 10,
                rearLength: '-70%'
                //baseLength: 80
            },
            pivot: {
                radius: 0
            }
        }
    },
    pane: {
        startAngle: -70,
        endAngle: 70,
        background: [{
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#FFF'],
                    [1, '#333']
                ]
            },
            borderWidth: 0,
            outerRadius: '100%'
        }, {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#333'],
                    [1, '#FFF']
                ]
            },
            borderWidth: 0,
            outerRadius: '100%'
        }, {
            // default background
        }, {
            backgroundColor: '#DDD',
            borderWidth: 0,
            outerRadius: '104%',
            innerRadius: '104%'
        }]
    },
    // the value axis
    yAxis: {
        min: 0,
        max: 100,

        minorTickInterval: 'auto',
        minorTickWidth: 1,
        minorTickLength: 7,
        minorTickPosition: 'inside',
        minorTickColor: '#666',

        tickPixelInterval: 30,
        tickWidth: 2,
        tickPosition: 'inside',
        tickLength: 10,
        tickColor: '#666',
        labels: {
            step: 2,
            rotation: 'auto'
        },
        plotBands: [{
            from: 0,
            to: 75,
            color: '#55BF3B' // green
        }, {
            from: 75,
            to: 90,
            color: '#DDDF0D' // yellow
        }, {
            from: 90,
            to: 100,
            color: '#DF5353' // red
        }]
    },
    tooltip: {
        valueSuffix: ' ChangeMe',
        positioner: function () {
            return { x: 50, y: 50 };
        }
    },
    series: [{
        dataLabels: {
            enabled: false
        },
        data: [0]
    }]
};

var bottomChartOptions = {
    chart: {
        renderTo: 'bottomChart',
        type: 'gauge',
        plotBackgroundColor: null,
        plotBackgroundImage: null,
        plotBorderWidth: 0,
        plotShadow: false,
        marginTop: -221
    },
    credits: {enabled: false},
    title: {
        text: ''
    },
    plotOptions: {
        gauge: {
            dial: {
                radius: '75%',
                baseWidth: 10,
                rearLength: '-70%'
                //baseLength: 80
            },
            pivot: {
                radius: 0
            }
        }
    },
    pane: {
        startAngle: 110,
        endAngle: 250,
        background: [{
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#FFF'],
                    [1, '#333']
                ]
            },
            borderWidth: 0,
            outerRadius: '100%'
        }, {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#333'],
                    [1, '#FFF']
                ]
            },
            borderWidth: 0,
            outerRadius: '100%'
        }, {
            // default background
        }, {
            backgroundColor: '#DDD',
            borderWidth: 0,
            outerRadius: '104%',
            innerRadius: '104%'
        }]
    },

    // the value axis
    yAxis: {
        min: 0,
        max: 100,

        minorTickInterval: 'auto',
        minorTickWidth: 1,
        minorTickLength: 7,
        minorTickPosition: 'inside',
        minorTickColor: '#666',

        tickPixelInterval: 30,
        tickWidth: 2,
        tickPosition: 'inside',
        tickLength: 10,
        tickColor: '#666',
        labels: {
            step: 2,
            rotation: 'auto'
        },
        title: {
            text: ''
        },
        plotBands: [{
            from: 0,
            to: 75,
            color: '#55BF3B' // green
        }, {
            from: 75,
            to: 90,
            color: '#DDDF0D' // yellow
        }, {
            from: 90,
            to: 100,
            color: '#DF5353' // red
        }]
    },
    tooltip: {
        valueSuffix: ' ChangeMe',
        positioner: function () {
            return { x: 50, y: 50 };
        }
    },
    series: [{
        dataLabels: {
            enabled: false
        },
        data: [0]
    }]
};
//////////////////////////////////

// Clear alerts and save settings on configuration closure
$("#closeSettings").click(function() {
    saveSettings();
});
$("#closeNoSave").click(function() {
    $("#widgetSettings").slideUp();
});
// Open config panel on double-click
$("#chart-div").dblclick(function() {
    showEditPanel();
});
// Toggle debug logging on double-click of 'eye' icon
$("#visualOptionsIcon").dblclick(function() {
    if (debugMode == null) {
        debugMode = true;
        console.log('Gadget #' + gadgetInstanceId + ' - Debug logging enabled');
    } else if (debugMode == true) {
        debugMode = false;
        console.log('Gadget #' + gadgetInstanceId + ' - Debug logging disabled');
    }
});

function populateDevices() {
    requestString = getMetricsPath + '?uptime_host=' + uptimeHost + '&query_type=network_devices';
    if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Requesting: ' + requestString)};
    $.getJSON(requestString, function(data) {
    }).done(function(data) {
            if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Request succeeded!')};
            $("select.devices").empty();
            $.each(data, function(key, val) {
                $("select.devices").append('<option value="' + val + '">' + key + '</option>');
            });
            if (typeof deviceId !== 'undefined') {
                if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Setting network device dropdown to: '
                    + deviceId)};
                $("select.devices").val(deviceId).trigger("chosen:updated").trigger('change');
            } else {
                $("select.devices").trigger("chosen:updated").trigger('change');
            }
            $("#device-count").text($('#devices option').length);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.log('Gadget #' + gadgetInstanceId + ' - Request failed! ' + textStatus);
        }).always(function() {
            // console.log('Request completed.');
        });
}

function populatePorts() {
    requestString = getMetricsPath  + '?uptime_host=' + uptimeHost + '&query_type=network_ports'
                                    + '&device_id=' + deviceId;
    if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Requesting: ' + requestString)};
    $.getJSON(requestString, function(data) {
    }).done(function(data) {
            if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Request succeeded!')};
            $("select.ports").empty();
            $.each(data, function(key, val) {
                $("select.ports").append('<option value="' + val + '">' + key + '</option>');
            });
            if (typeof portId !== 'undefined') {
                if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Setting network port dropdown to: '
                    + portId)};
                $("select.ports").val(portId).trigger("chosen:updated").trigger('change');
            } else {
                $("select.ports").trigger("chosen:updated").trigger('change');
            }
            $("#port-count").text($('#ports option').length);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.log('Gadget #' + gadgetInstanceId + ' - Request failed! ' + textStatus);
        }).always(function() {
            // console.log('Request completed.');
        });
}

// Device changed
$("select.devices").on('change', function(evt, params) {
    deviceId = $("select.devices").val();
    $("#port-count").text($('#ports option').length);
    populatePorts();
});

// Key functions
function populateOptions() {

    $("#refreshIntervalSlider").slider({
        range: "max", value: 4, min: 1, max: 5, animate: true,
        slide: function( event, ui ) {
            $("#refreshIntervalLabelContents").text('Every '
                + refreshIntervalOptions[refreshIntervalSliderOptions[ui.value]]);
        }
    });

    if (typeof refreshInterval !== 'undefined') {
        if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Setting refresh interval slider to: '
            + refreshInterval)};
        $.each(refreshIntervalSliderOptions, function(k, v) {
            if (v == refreshInterval) {
                if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Setting refresh rate to: '
                    + refreshInterval + ' and refreshRateSlider to '
                    + refreshIntervalOptions[refreshIntervalSliderOptions[k]])};
                $("#refreshIntervalSlider").slider("option", "value", k);
                $("#refreshIntervalLabelContents").text('Every '
                    + refreshIntervalOptions[refreshIntervalSliderOptions[k]]);
            }
        });
    }

    if (typeof thresholdValues !== 'undefined') {
        if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Setting warning threshold slider to: '
            + thresholdValues[0] + ' and critical threshold slider to' + thresholdValues[1])};
        thresholdValues = [thresholdValues[0], thresholdValues[1]];
    } else {
        thresholdValues = [75, 90];
    }

    $("#thresholdSlider").slider({
        range: true, values: thresholdValues, min: 1, max: 100, animate: true,
        slide: function( event, ui ) {
            $("#warningThreshold").text('Warning: ' + ui.values[0]);
            $("#criticalThreshold").text('Critical: ' + ui.values[1]);
            thresholdValues = [ui.values[0], ui.values[1]];
        }
    });

    $("select.devices").chosen();
    $("select.ports").chosen();
    $("select.metrics").chosen();

    populateDevices();

    $("select.metrics").append('<option selected value="traffic">Traffic Rate (In+Out)</option>');
    $("select.metrics").append('<option disabled value="discards">More metrics to come!</option>');
    $("select.metrics").trigger("chosen:updated");

}

function showEditPanel() {
    if (myChart) {
        myChart.stopTimer();
    }
    $("#widgetBody").slideDown(function() {
        $("#widgetSettings").slideDown();
    });
    $("#widgetChart").height($(window).height());
}

function saveSettings() {
    settings.deviceId = $("select.devices").val();
    settings.portId = $("select.ports").val();
    settings.metricId = $("select.metrics").val();
    settings.thresholdValues = $("#thresholdSlider").slider("option", "values");
    settings.seriesTitle = $('select.metrics option:selected').text();
    refreshIntervalIndex = $("#refreshIntervalSlider").slider("value");
    settings.refreshInterval = refreshIntervalSliderOptions[refreshIntervalIndex];

    console.log('Gadget #' + gadgetInstanceId + ' - Saved settings: ' + printSettings(settings));
    uptimeGadget.saveSettings(settings).then(onGoodSave, onBadAjax);
}

function loadSettings(settings) {
    console.log('Gadget #' + gadgetInstanceId + ' - Loaded settings: ' + printSettings(settings));

    showEditPanel();

    deviceId = settings.deviceId;
    portId = settings.portId;
    metricId = settings.metricId;
    thresholdValues = settings.thresholdValues;
    refreshInterval = settings.refreshInterval;
    seriesTitle = settings.seriesTitle;
}

function goodLoad(settings) {
    clearStatusBar();
    if (settings) {
        loadSettings(settings);
        displayChart(settings);
    } else if (uptimeGadget.isOwner()) { // What does this do?
        $('#widgetChart').hide();
        showEditPanel();
    }
}

function onGoodSave() {
    clearStatusBar();
    displayChart(settings);
}

function printSettings(settings) {
    var printString = 'deviceId: ' + settings.deviceId + ', portId: ' + settings.portId + ', metricId: ' + settings.metricId
                    + ', thresholdValues: ' + settings.thresholdValues + ', refreshInterval: ' + settings.refreshInterval
                    + ', seriesTitle: ' + settings.seriesTitle;
    return printString;
}

function displayChart(settings) {
    if (myChart)  { myChart.stopTimer();
                    myChart.destroy();
                    myChart = null};

    if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Graph refresh rate: '
        + (settings.refreshInterval / 1000) + ' seconds')};

    renderChart(settings);
    clearInterval(interval);
    interval = setInterval(function() {
                    renderChart(settings, renderSuccessful)},
                                   settings.refreshInterval)
}

function renderChart(settings) {
    $("#closeSettings").button('loading');
    $("#widgetBody").slideUp();
    $("#loading-div").show('fade');

    $('#topChart').empty();
    $('#bottomChart').empty();

    requestString = getMetricsPath  + '?uptime_host=' + uptimeHost + '&query_type=network_port_metrics'
                                    + '&device_id=' + settings.deviceId + '&port_id=' + settings.portId;
    if (debugMode) {console.log('Gadget #' + gadgetInstanceId + ' - Requesting: ' + requestString)};

    var ajaxRequest = $.ajax({url: requestString,
            dataType: 'json'},
        function(data) {})
    .done (function( data ) {
        if (data.length < 1) {
            errorMessage = "There isn't enough monitoring data available for this port.";
            displayError(errorMessage,requestString);
            showEditPanel();
            $("#closeSettings").button('reset');
            $("#widgetBody").slideDown();
            $("#loading-div").hide('fade');
        } else {
            // Parse JSON response
            time_stamp = data[0][0];
            if (data[0][1]) {
                if_speed = data[0][1]["if_speed"];
                kbps_in_rate = data[0][1]["kbps_in_rate"];
                kbps_out_rate = data[0][1]["kbps_out_rate"];
                kbps_total_rate = data[0][1]["kbps_total_rate"];
                percent_in_rate = Math.round(((kbps_in_rate / if_speed) * 100), 2);
                mbps_in_rate = Math.round((kbps_in_rate / 1000), 2);
                percent_out_rate = Math.round(((kbps_out_rate / if_speed) * 100), 2);
                mbps_out_rate = Math.round((kbps_out_rate / 1000), 2);
                percent_total_rate = Math.round((((kbps_total_rate / if_speed) * 100)) / 2, 2);
                mbps_total_rate = Math.round((kbps_total_rate / 1000), 2);

                if (debugMode) {
                    console.log('Gadget #' + gadgetInstanceId + ' - Response: ' + JSON.stringify(data[0]))
                };

                $("#topChart").empty();
                $("#bottomChart").empty();
                $("#chartStats").show();

                topChartOptions.series[0].data = [parseInt(percent_in_rate)];
                bottomChartOptions.series[0].data = [parseInt(percent_out_rate)];
                topChartOptions.yAxis.plotBands = [{from: 0, to: thresholdValues[0], color: '#55BF3B'},
                                                    {from: thresholdValues[0], to: thresholdValues[1], color: '#DDDF0D'},
                                                    {from: thresholdValues[1], to: 100, color: '#DF5353'}];
                bottomChartOptions.yAxis.plotBands = [{from: 0, to: thresholdValues[0], color: '#55BF3B'},
                                                        {from: thresholdValues[0], to: thresholdValues[1], color: '#DDDF0D'},
                                                        {from: thresholdValues[1], to: 100, color: '#DF5353'}];
                var topChart = new Highcharts.Chart(topChartOptions);
                var bottomChart = new Highcharts.Chart(bottomChartOptions);

                $("#inboundMetricsContent").empty();
                $("#inboundMetricsContent").append(percent_in_rate + '% :: ' + mbps_in_rate + ' Mbps');
                $("#outboundMetricsContent").empty();
                $("#outboundMetricsContent").append(percent_out_rate + '% :: ' + mbps_out_rate + ' Mbps');
                $("#totalMetricsContent").empty();
                $("#totalMetricsContent").append(percent_total_rate + '% :: ' + mbps_total_rate + ' Mbps');

                $("#closeSettings").button('reset');
                $("#loading-div").hide('fade');
                $("#widgetSettings").slideUp();
                $("#alertModal").modal('hide');

            } else {
                errorMessage = "There isn't enough monitoring data available for this port.";
                displayError(errorMessage,requestString);
                showEditPanel();
                $("#closeSettings").button('reset');
                $("#loading-div").hide('fade');
                ajaxRequest.abort();
            }

//            discards_in_rate = data[0][1]["discards_in_rate"];        // To be added
//            discards_out_rate = data[0][1]["discards_out_rate"];      // To be added
//            discards_total_rate = data[0][1]["discards_total_rate"];  // To be added
//            errors_in_rate = data[0][1]["errors_in_rate"];            // To be added
//            errors_out_rate = data[0][1]["errors_out_rate"];          // To be added
//            errors_total_rate = data[0][1]["errors_total_rate"];      // To be added
//            usage_in_percent = data[0][1]["usage_in_percent"];       // Inconsistent
//            usage_out_percent = data[0][1]["usage_out_percent"];     // Inconsistent
//            usage_percent = data[0][1]["usage_percent"];             // Inconsistent

        }})
    .fail (function(jqXHR, textStatus, errorThrown) {
        errorMessage = 'HTTP Status Code ' + jqXHR.status;
        displayError(errorMessage,requestString);
        showEditPanel();
        $("#closeSettings").button('reset');
        $("#loading-div").hide('fade');
    });
}

function displayError(errorMessage,requestString) {
    console.log('Gadget #' + gadgetInstanceId + ' - Error: ' + errorMessage);
    $("#alertModalBody").empty();
    $("#alertModalBody").append('<p class="text-danger"><strong>Error:</strong> ' + errorMessage + '</p>'
        + 'Here is the request string which has resulted in this error:'
        + '<br><blockquote>' + requestString + '</blockquote>');
    $("#alertModal").modal('show');
}
// Static functions
function displayStatusBar(msg) {
    gadgetDimOn();
    var statusBar = $("#statusBar");
    statusBar.empty();
    var errorBox = uptimeErrorFormatter.getErrorBox(msg);
    errorBox.appendTo(statusBar);
    statusBar.slideDown();
}
function clearStatusBar() {
    gadgetDimOff();
    var statusBar = $("#statusBar");
    statusBar.slideUp().empty();
}
function resizeGadget(dimensions) {
    myChartDimensions = toMyChartDimensions(dimensions);
    if (myChart) {
        myChart.resize(myChartDimensions);
    }
    $("#widgetChart").height($(window).height());
}
function toMyChartDimensions(dimensions) {
    return new UPTIME.pub.gadgets.Dimensions(Math.max(100, dimensions.width - 5), Math.max(100, dimensions.height));
}
function onBadAjax(error) {
    displayStatusBar(error, "Error Communicating with up.time");
}
function gadgetDimOn() {
    $.each(divsToDim, function(i, d) {
        var div = $(d);
        if (div.is(':visible') && div.css('opacity') > 0.6) {
            div.fadeTo('slow', 0.3);
        }
    });
}
function gadgetDimOff() {
    $.each(divsToDim, function(i, d) {
        var div = $(d);
        if (div.is(':visible') && div.css('opacity') < 0.6) {
            div.fadeTo('slow', 1);
        }
    });
}